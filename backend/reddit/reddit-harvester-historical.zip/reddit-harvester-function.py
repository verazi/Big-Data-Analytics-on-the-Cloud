from reddit_harvester import main as reddit_main

# Fission function entry point
def main():
    """Fission function entry point for Reddit harvesting"""
    return reddit_main()
